import 'dart:async';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;
import '../constants/app_constants.dart';
import '../di/injection.dart';
import 'storage_service.dart';

// Import PatrolNotifier for static callback
import '../../features/patrol/presentation/providers/patrol_provider.dart';

/// Service for handling push notifications (FCM) and local notifications
class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotif = FlutterLocalNotificationsPlugin();
  final AudioPlayer _alarmPlayer = AudioPlayer();

  NotificationApi? _notificationApi;
  StorageService? _storage;

  bool _isInitialized = false;
  bool _isAlarmPlaying = false;
  bool _isAlarmDismissed = false;
  bool _isRegisteringToken = false;

  /// Callback when patrol alarm is received (foreground only)
  void Function(String? message)? onPatrolAlarmReceived;

  /// Initialize notification service
  /// Call this after Firebase.initializeApp() in main()
  Future<void> init({
    NotificationApi? notificationApi,
    StorageService? storage,
  }) async {
    if (_isInitialized) return;

    _notificationApi = notificationApi;
    _storage = storage;

    // Initialize timezone for scheduled notifications
    tz_data.initializeTimeZones();

    // Configure alarm audio player for looping
    await _alarmPlayer.setReleaseMode(ReleaseMode.loop);
    await _alarmPlayer.setVolume(1.0);

    // Setup local notifications
    await _initLocalNotifications();

    // Setup FCM handlers
    await _initFcm();

    _isInitialized = true;
  }

  /// Initialize local notifications plugin
  Future<void> _initLocalNotifications() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _localNotif.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _handleLocalNotificationTap,
    );

    // Create patrol alarm channel (Android only)
    if (Platform.isAndroid) {
      const androidChannel = AndroidNotificationChannel(
        'patrol_alarm',
        'Alarm Patroli',
        description: 'Notifikasi wajib patroli checkpoint berikutnya',
        importance: Importance.max,
        playSound: true,
        enableVibration: true,
        // Note: custom sound requires file in android/app/src/main/res/raw/
        // If file not present, use default sound
      );

      await _localNotif
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.createNotificationChannel(androidChannel);

      // Create default channel for regular notifications (shift reminders, etc.)
      const defaultChannel = AndroidNotificationChannel(
        'default',
        'Notifikasi',
        description: 'Notifikasi umum',
        importance: Importance.high,
        playSound: true,
        enableVibration: true,
      );

      await _localNotif
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.createNotificationChannel(defaultChannel);
    }
  }

  /// Initialize FCM
  Future<void> _initFcm() async {
    // Request permission
    final settings = await _fcm.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: true,
      provisional: false,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.denied) {
      debugPrint('NotificationService: FCM permission denied');
      // Permission denied - could show explanation in Settings screen
    }

    // Handle initial message (app opened from terminated state via notification)
    final initialMessage = await _fcm.getInitialMessage();
    if (initialMessage != null) {
      _handleFcmTap(initialMessage);
    }

    // Handle when app is opened from background via notification tap
    FirebaseMessaging.onMessageOpenedApp.listen(_handleFcmTap);

    // Handle foreground messages
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);

    // Listen to token refresh (instance member)
    _fcm.onTokenRefresh.listen(_registerToken);
  }

  /// Handle foreground FCM message
  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    debugPrint('NOTIF: _handleForegroundMessage called');
    debugPrint('NOTIF: data=${message.data}');
    debugPrint('NOTIF: notification title=${message.notification?.title}');

    final data = message.data;
    final title = message.notification?.title ?? 'Notifikasi';
    final body = message.notification?.body ?? 'Pesan baru';

    final isAlarm = data['type'] == 'patrol_alarm';

    // Check if this is a patrol alarm
    if (isAlarm && !_isAlarmDismissed) {
      debugPrint('NOTIF: This is a patrol_alarm!');
      _isAlarmPlaying = true;
      // Play looping alarm sound
      try {
        await _alarmPlayer.stop();
        await _alarmPlayer.play(AssetSource('sounds/alarm.mp3'));
        debugPrint('NotificationService: Alarm sound started (looping)');
      } catch (e) {
        debugPrint('NotificationService: Failed to play alarm sound: $e');
      }

      // Navigate to alarm screen via static callback
      final alarmMessage = message.notification?.body ?? 'Waktunya patroli checkpoint berikutnya!';
      debugPrint('NOTIF: Calling PatrolNotifier.onAlarmNavigated with: $alarmMessage');
      PatrolNotifier.onAlarmNavigated?.call(alarmMessage);
    }

    await _showLocalNotification(
      title: title,
      body: body,
      payload: data['type'] ?? 'default',
      isAlarm: isAlarm,
    );
  }

  /// Show local notification
  Future<void> _showLocalNotification({
    required String title,
    required String body,
    String? payload,
    bool isAlarm = true,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      isAlarm ? 'patrol_alarm' : 'default',
      isAlarm ? 'Alarm Patroli' : 'Notifikasi',
      channelDescription: isAlarm
          ? 'Notifikasi patroli checkpoint'
          : 'Notifikasi umum',
      importance: isAlarm ? Importance.max : Importance.high,
      priority: isAlarm ? Priority.high : Priority.high,
      ongoing: isAlarm,
      autoCancel: !isAlarm,
      enableVibration: true,
      playSound: true,
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    final details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _localNotif.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      title,
      body,
      details,
      payload: payload,
    );
  }

  /// Handle notification tap (FCM - background/terminated)
  void _handleFcmTap(RemoteMessage message) {
    debugPrint('NotificationService: FCM notification tapped: ${message.data}');

    // Stop alarm sound (only for patrol alarms)
    if (message.data['type'] == 'patrol_alarm') {
      _stopAlarmSound();
      _navigateToPatrol();
    } else if (message.data['type'] == 'shift_reminder') {
      // Navigate to schedule screen for shift reminders
      _navigateToSchedule();
    }
  }

  /// Handle local notification tap
  void _handleLocalNotificationTap(NotificationResponse response) {
    debugPrint('NotificationService: Local notification tapped: ${response.payload}');

    final payload = response.payload;
    if (payload == 'patrol_alarm') {
      // Stop alarm sound and navigate to patrol screen
      _stopAlarmSound();
      _navigateToPatrol();
    } else if (payload == 'shift_reminder') {
      // Navigate to schedule screen for shift reminders
      _navigateToSchedule();
    }
  }

  /// Stop alarm sound and reset state
  void _stopAlarmSound() {
    if (_isAlarmPlaying) {
      _alarmPlayer.stop();
      _isAlarmPlaying = false;
      _isAlarmDismissed = false; // Reset for next alarm
      debugPrint('NotificationService: Alarm sound stopped');
    }
  }

  /// Reset alarm dismissed state (call when patrol round is complete)
  void resetAlarmDismissed() {
    _isAlarmDismissed = false;
  }

  /// Navigate to patrol screen
  void _navigateToPatrol() {
    // This will be called from main.dart which handles actual navigation
    // We use a callback mechanism instead of directly accessing router
    debugPrint('NotificationService: Should navigate to /patrol');
  }

  /// Navigate to schedule screen
  void _navigateToSchedule() {
    // This will be called from main.dart which handles actual navigation
    // We use a callback mechanism instead of directly accessing router
    debugPrint('NotificationService: Should navigate to /schedule');
  }

  /// Register FCM token with backend
  Future<void> _registerToken(String token) async {
    debugPrint('NOTIF_DEBUG: FCM Token = $token');

    // Prevent multiple simultaneous registrations
    if (_isRegisteringToken) {
      debugPrint('NotificationService: Token registration already in progress, skipping');
      return;
    }
    _isRegisteringToken = true;

    if (_notificationApi == null || _storage == null) {
      debugPrint('NotificationService: API or storage not initialized');
      _isRegisteringToken = false;
      return;
    }

    try {
      // Get or generate device ID
      String? deviceId = await _storage!.deviceId;
      debugPrint('NOTIF_DEBUG: deviceId from storage = $deviceId');

      if (deviceId == null || deviceId.isEmpty) {
        deviceId = _generateDeviceId();
        await _storage!.setDeviceId(deviceId);
        debugPrint('NOTIF_DEBUG: Generated new deviceId = $deviceId');
      } else {
        debugPrint('NOTIF_DEBUG: Using existing deviceId = $deviceId');
      }

      // Determine platform
      final platform = Platform.isAndroid ? 'android' : 'ios';

      // Register with backend
      await _notificationApi!.registerDeviceToken(
        token: token,
        platform: platform,
        deviceId: deviceId,
      );

      // Store token locally
      await _storage!.setFcmToken(token);

      debugPrint('NotificationService: Token registered successfully');
    } catch (e) {
      debugPrint('NotificationService: Failed to register token: $e');
    } finally {
      _isRegisteringToken = false;
    }
  }

  /// Generate a unique device ID
  String _generateDeviceId() {
    return 'device_${DateTime.now().millisecondsSinceEpoch}_${(DateTime.now().microsecond % 10000).toString().padLeft(4, '0')}';
  }

  /// Get current FCM token
  Future<String?> getToken() async {
    return _fcm.getToken();
  }

  /// Register current token (call after login when user is authenticated)
  Future<void> registerCurrentToken() async {
    try {
      final token = await _fcm.getToken();
      if (token != null) {
        await _registerToken(token);
      }
    } catch (e) {
      debugPrint('NotificationService: Failed to register current token: $e');
    }
  }

  /// Unregister FCM token (call on logout)
  Future<void> unregisterToken() async {
    if (_notificationApi == null) return;

    try {
      final token = await _fcm.getToken();
      if (token != null) {
        await _notificationApi!.unregisterDeviceToken(token);
        if (_storage != null) {
          await _storage!.removeFcmToken();
        }
      }
    } catch (e) {
      debugPrint('NotificationService: Failed to unregister token: $e');
    }
  }

  /// Schedule patrol alarm notification
  Future<void> schedulePatrolAlarm({
    required DateTime scheduledTime,
    String? roundInfo,
  }) async {
    if (!_isInitialized) {
      debugPrint('NotificationService: Not initialized, cannot schedule alarm');
      return;
    }

    // Cancel any existing patrol alarm notification first
    await cancelPatrolAlarm();

    // Don't schedule if time is in the past
    if (scheduledTime.isBefore(DateTime.now())) {
      debugPrint('NotificationService: Scheduled time is in the past, skipping');
      return;
    }

    final androidDetails = AndroidNotificationDetails(
      'patrol_alarm',
      'Alarm Patroli',
      channelDescription: 'Notifikasi wajib patroli checkpoint berikutnya',
      importance: Importance.max,
      priority: Priority.high,
      ongoing: true,
      autoCancel: false,
      enableVibration: true,
      playSound: true,
      styleInformation: BigTextStyleInformation(
        roundInfo ?? 'Waktunya patroli checkpoint berikutnya! Segera lakukan scan checkpoint.',
        contentTitle: 'Alarm Patroli - Checkpoint Berikutnya',
        summaryText: 'Patroli',
      ),
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    final details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _localNotif.zonedSchedule(
      AppConstants.patrolAlarmNotificationId,
      'Alarm Patroli',
      roundInfo ?? 'Waktunya patroli checkpoint berikutnya!',
      tz.TZDateTime.from(scheduledTime, tz.local),
      details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: 'patrol_alarm',
    );

    debugPrint('NotificationService: Scheduled patrol alarm at $scheduledTime');
  }

  /// Cancel patrol alarm notification
  Future<void> cancelPatrolAlarm() async {
    await _localNotif.cancel(AppConstants.patrolAlarmNotificationId);
    debugPrint('NotificationService: Cancelled patrol alarm notification');
  }

  /// Show immediate patrol alarm notification
  Future<void> _showPatrolAlarmNotification({
    required String title,
    required String body,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      'patrol_alarm',
      'Alarm Patroli',
      channelDescription: 'Notifikasi wajib patroli checkpoint berikutnya',
      importance: Importance.max,
      priority: Priority.high,
      ongoing: true,
      autoCancel: false,
      enableVibration: true,
      playSound: true,
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    final details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _localNotif.show(
      AppConstants.patrolAlarmNotificationId,
      title,
      body,
      details,
      payload: 'patrol_alarm',
    );
  }

  /// Cancel all notifications
  Future<void> cancelAll() async {
    await _localNotif.cancelAll();
  }

  /// Request notification permission (for Android 13+)
  Future<bool> requestNotificationPermission() async {
    if (Platform.isAndroid) {
      final android = _localNotif.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

      if (android != null) {
        final granted = await android.requestNotificationsPermission();
        return granted ?? false;
      }
    }
    return true;
  }

  /// Check if notifications are enabled
  Future<bool> areNotificationsEnabled() async {
    if (Platform.isAndroid) {
      final android = _localNotif.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

      if (android != null) {
        return await android.areNotificationsEnabled() ?? false;
      }
    }
    return true;
  }

  /// Stop alarm sound (call this when user dismisses alarm)
  Future<void> stopAlarm() async {
    _stopAlarmSound();
  }

  /// Check if alarm is currently playing
  bool get isAlarmPlaying => _isAlarmPlaying;
}

/// Top-level background handler for FCM (REQUIRED to be top-level function)
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // If Firebase is not yet initialized, initialize it
  // This is called when app is in background/terminated
  debugPrint('NotificationService: Handling background message: ${message.data}');

  // Handle patrol alarm if it's a patrol notification
  if (message.data['type'] == 'patrol_alarm') {
    // Background handler - notification will be shown by system
    // Just log for now
    debugPrint('NotificationService: Background patrol alarm received');
  }
}
