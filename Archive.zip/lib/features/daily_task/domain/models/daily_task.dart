// Daily Task entities
import '../../../../shared/constants/condition_constants.dart';

class DailyTask {
  final int id;
  final String itemName;
  final String? itemDescription;
  final String? areaName;
  final int? areaId;
  final String status;
  final int? targetMinutes;
  final String? targetNote;
  final DateTime? startAt;
  final DateTime? endAt;
  final List<DailyTaskPhoto> photos;
  final List<DailyTaskTool>? tools;
  final List<DailyTaskChemical>? chemicals;
  final List<DailyTaskPpe>? ppes;
  final List<DailyTaskMachine>? machines;
  final List<DailyTaskReview>? reviews;
  final int? durationMinutes;
  final String? notes;
  final String? assignedBy;
  final DateTime? assignedDate;
  final String? employeeName;
  final List<String>? assignedEmployeeNames;

  DailyTask({
    required this.id,
    required this.itemName,
    this.itemDescription,
    this.areaName,
    this.areaId,
    required this.status,
    this.targetMinutes,
    this.targetNote,
    this.startAt,
    this.endAt,
    this.photos = const [],
    this.tools,
    this.chemicals,
    this.ppes,
    this.machines,
    this.reviews,
    this.durationMinutes,
    this.notes,
    this.assignedBy,
    this.assignedDate,
    this.employeeName,
    this.assignedEmployeeNames,
  });

  factory DailyTask.fromJson(Map<String, dynamic> json) {
    return DailyTask(
      id: int.tryParse(json['id']?.toString() ?? '') ?? 0,
      itemName: json['item_name'] as String? ?? '',
      itemDescription: json['item_description'] as String?,
      areaName: json['area_name'] as String?,
      areaId: json['area_id'] as int?,
      status: json['status'] as String? ?? 'assigned',
      targetMinutes: json['target_minutes'] as int?,
      targetNote: json['target_note'] as String?,
      startAt: json['start_at'] != null
          ? DateTime.tryParse(json['start_at'] as String)
          : null,
      endAt: json['end_at'] != null
          ? DateTime.tryParse(json['end_at'] as String)
          : null,
      photos: (json['photos'] as List<dynamic>?)
              ?.map((p) => DailyTaskPhoto.fromJson(p as Map<String, dynamic>))
              .toList() ??
          [],
      tools: (json['tools'] as List<dynamic>?)
          ?.map((t) => DailyTaskTool.fromJson(t as Map<String, dynamic>))
          .toList(),
      chemicals: (json['chemicals'] as List<dynamic>?)
          ?.map((c) => DailyTaskChemical.fromJson(c as Map<String, dynamic>))
          .toList(),
      ppes: (json['ppes'] as List<dynamic>?)
          ?.map((p) => DailyTaskPpe.fromJson(p as Map<String, dynamic>))
          .toList(),
      machines: (json['machines'] as List<dynamic>?)
          ?.map((m) => DailyTaskMachine.fromJson(m as Map<String, dynamic>))
          .toList(),
      reviews: (json['reviews'] as List<dynamic>?)
          ?.map((r) => DailyTaskReview.fromJson(r as Map<String, dynamic>))
          .toList(),
      durationMinutes: json['duration_minutes'] as int?,
      notes: json['notes'] as String?,
      assignedBy: json['assigned_by'] as String?,
      assignedDate: json['assigned_date'] != null
          ? DateTime.tryParse(json['assigned_date'] as String)
          : null,
      employeeName: json['employee_name'] as String?,
      assignedEmployeeNames: (json['employee_names'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
    );
  }

  String get statusLabel {
    switch (status) {
      case 'assigned':
        return 'Ditugaskan';
      case 'in_progress':
        return 'Sedang Dikerjakan';
      case 'completed':
        return 'Selesai';
      case 'reviewed':
        return 'Direview';
      default:
        return status;
    }
  }

  bool get canStart => status == 'assigned';
  bool get canFinish => status == 'in_progress';
}

class DailyTaskPhoto {
  final int id;
  final String type;
  final String url;

  DailyTaskPhoto({
    required this.id,
    required this.type,
    required this.url,
  });

  factory DailyTaskPhoto.fromJson(Map<String, dynamic> json) {
    return DailyTaskPhoto(
      id: int.tryParse(json['id']?.toString() ?? '') ?? 0,
      type: json['type'] as String? ?? 'before',
      url: json['url'] as String? ?? '',
    );
  }
}

class DailyTaskTool {
  final int id;
  final String name;
  final String? qrCode;
  final String? condition;
  final String? conditionLabel;
  final String? initialCondition;
  final String? finalCondition;
  // Current condition from ProductArea
  final double? currentStock;
  final String? currentCondition;
  final String? currentConditionLabel;

  DailyTaskTool({
    required this.id,
    required this.name,
    this.qrCode,
    this.condition,
    this.conditionLabel,
    this.initialCondition,
    this.finalCondition,
    this.currentStock,
    this.currentCondition,
    this.currentConditionLabel,
  });

  factory DailyTaskTool.fromJson(Map<String, dynamic> json) {
    return DailyTaskTool(
      id: int.tryParse(json['id']?.toString() ?? '') ?? 0,
      name: json['name'] as String? ?? '',
      qrCode: json['qr_code'] as String?,
      condition: json['condition'] as String?,
      conditionLabel: json['condition_label'] as String?,
      initialCondition: json['initial_condition'] as String?,
      finalCondition: json['final_condition'] as String?,
      currentStock: (json['current_stock'] as num?)?.toDouble(),
      currentCondition: json['current_condition'] as String?,
      currentConditionLabel: json['current_condition_label'] as String?,
    );
  }

  String? get initialConditionLabel =>
      ItemConditions.getFullLabel(initialCondition);
}

class DailyTaskChemical {
  final int id;
  final String name;
  final String? qrCode;
  final String? condition;
  final String? conditionLabel;
  final String? initialCondition;
  final String? finalCondition;
  // Current condition from ProductArea
  final double? currentStock;
  final String? currentCondition;
  final String? currentConditionLabel;

  DailyTaskChemical({
    required this.id,
    required this.name,
    this.qrCode,
    this.condition,
    this.conditionLabel,
    this.initialCondition,
    this.finalCondition,
    this.currentStock,
    this.currentCondition,
    this.currentConditionLabel,
  });

  factory DailyTaskChemical.fromJson(Map<String, dynamic> json) {
    return DailyTaskChemical(
      id: int.tryParse(json['id']?.toString() ?? '') ?? 0,
      name: json['name'] as String? ?? '',
      qrCode: json['qr_code'] as String?,
      condition: json['condition'] as String?,
      conditionLabel: json['condition_label'] as String?,
      initialCondition: json['initial_condition'] as String?,
      finalCondition: json['final_condition'] as String?,
      currentStock: (json['current_stock'] as num?)?.toDouble(),
      currentCondition: json['current_condition'] as String?,
      currentConditionLabel: json['current_condition_label'] as String?,
    );
  }

  String? get initialConditionLabel =>
      ItemConditions.getFullLabel(initialCondition);
}

class DailyTaskPpe {
  final int id;
  final String name;
  final String? qrCode;
  final String? condition;
  final String? conditionLabel;
  final String? initialCondition;
  final String? finalCondition;
  // Current condition from ProductArea
  final double? currentStock;
  final String? currentCondition;
  final String? currentConditionLabel;

  DailyTaskPpe({
    required this.id,
    required this.name,
    this.qrCode,
    this.condition,
    this.conditionLabel,
    this.initialCondition,
    this.finalCondition,
    this.currentStock,
    this.currentCondition,
    this.currentConditionLabel,
  });

  factory DailyTaskPpe.fromJson(Map<String, dynamic> json) {
    return DailyTaskPpe(
      id: int.tryParse(json['id']?.toString() ?? '') ?? 0,
      name: json['name'] as String? ?? '',
      qrCode: json['qr_code'] as String?,
      condition: json['condition'] as String?,
      conditionLabel: json['condition_label'] as String?,
      initialCondition: json['initial_condition'] as String?,
      finalCondition: json['final_condition'] as String?,
      currentStock: (json['current_stock'] as num?)?.toDouble(),
      currentCondition: json['current_condition'] as String?,
      currentConditionLabel: json['current_condition_label'] as String?,
    );
  }

  String? get initialConditionLabel =>
      ItemConditions.getFullLabel(initialCondition);
}

class DailyTaskReview {
  final int id;
  final String? reviewerName;
  final String? notes;
  final DateTime? reviewedAt;
  final List<DailyTaskReviewScore> scores;

  DailyTaskReview({
    required this.id,
    this.reviewerName,
    this.notes,
    this.reviewedAt,
    this.scores = const [],
  });

  factory DailyTaskReview.fromJson(Map<String, dynamic> json) {
    return DailyTaskReview(
      id: int.tryParse(json['id']?.toString() ?? '') ?? 0,
      reviewerName: json['reviewer_name'] as String?,
      notes: json['notes'] as String?,
      reviewedAt: json['reviewed_at'] != null
          ? DateTime.tryParse(json['reviewed_at'] as String)
          : null,
      scores: (json['scores'] as List<dynamic>?)
              ?.map((s) => DailyTaskReviewScore.fromJson(s as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }

  double? get averageScore {
    if (scores.isEmpty) return null;
    return scores.map((s) => s.score).reduce((a, b) => a + b) / scores.length;
  }
}

class DailyTaskReviewScore {
  final int criteriaId;
  final String? criteriaName;
  final int score;

  DailyTaskReviewScore({
    required this.criteriaId,
    this.criteriaName,
    required this.score,
  });

  factory DailyTaskReviewScore.fromJson(Map<String, dynamic> json) {
    return DailyTaskReviewScore(
      criteriaId: int.tryParse(json['criteria_id']?.toString() ?? '') ?? 0,
      criteriaName: json['criteria_name'] as String?,
      score: json['score'] as int? ?? 0,
    );
  }
}

class DailyTaskMachine {
  final int id;
  final String name;
  final String? qrCode;
  final String? condition;
  final String? conditionLabel;
  final String? initialCondition;
  final String? finalCondition;
  // Current condition from ProductArea
  final double? currentStock;
  final String? currentCondition;
  final String? currentConditionLabel;

  DailyTaskMachine({
    required this.id,
    required this.name,
    this.qrCode,
    this.condition,
    this.conditionLabel,
    this.initialCondition,
    this.finalCondition,
    this.currentStock,
    this.currentCondition,
    this.currentConditionLabel,
  });

  factory DailyTaskMachine.fromJson(Map<String, dynamic> json) {
    return DailyTaskMachine(
      id: int.tryParse(json['id']?.toString() ?? '') ?? 0,
      name: json['name'] as String? ?? '',
      qrCode: json['qr_code'] as String?,
      condition: json['condition'] as String?,
      conditionLabel: json['condition_label'] as String?,
      initialCondition: json['initial_condition'] as String?,
      finalCondition: json['final_condition'] as String?,
      currentStock: (json['current_stock'] as num?)?.toDouble(),
      currentCondition: json['current_condition'] as String?,
      currentConditionLabel: json['current_condition_label'] as String?,
    );
  }

  String? get initialConditionLabel =>
      ItemConditions.getFullLabel(initialCondition);
}

class DailyTaskMasterItem {
  final int id;
  final String name;
  final String? description;
  final int? roleId;
  final String? roleName;

  DailyTaskMasterItem({
    required this.id,
    required this.name,
    this.description,
    this.roleId,
    this.roleName,
  });

  factory DailyTaskMasterItem.fromJson(Map<String, dynamic> json) {
    return DailyTaskMasterItem(
      id: int.tryParse(json['id']?.toString() ?? '') ?? 0,
      name: json['name'] as String? ?? '',
      description: json['description'] as String?,
      roleId: json['role_id'] as int?,
      roleName: json['role_name'] as String?,
    );
  }
}

class DailyTaskRole {
  final int id;
  final String name;
  final int? parentRoleId;

  DailyTaskRole({
    required this.id,
    required this.name,
    this.parentRoleId,
  });

  factory DailyTaskRole.fromJson(Map<String, dynamic> json) {
    return DailyTaskRole(
      id: int.tryParse(json['id']?.toString() ?? '') ?? 0,
      name: json['name'] as String? ?? '',
      parentRoleId: json['parent_role_id'] != null
          ? int.tryParse(json['parent_role_id'].toString())
          : null,
    );
  }
}

/// Progress check model for task observation
class DailyTaskProgressCheck {
  final int id;
  final int employeeId;
  final String? employeeName;
  final int checkedBy;
  final String? checkedByName;
  final String mediaType;
  final String mediaUrl;
  final String? notes;
  final DateTime? checkedAt;

  DailyTaskProgressCheck({
    required this.id,
    required this.employeeId,
    this.employeeName,
    required this.checkedBy,
    this.checkedByName,
    required this.mediaType,
    required this.mediaUrl,
    this.notes,
    this.checkedAt,
  });

  factory DailyTaskProgressCheck.fromJson(Map<String, dynamic> json) {
    return DailyTaskProgressCheck(
      id: int.tryParse(json['id']?.toString() ?? '') ?? 0,
      employeeId: int.tryParse(json['employee_id']?.toString() ?? '') ?? 0,
      employeeName: json['employee_name'] as String?,
      checkedBy: int.tryParse(json['checked_by']?.toString() ?? '') ?? 0,
      checkedByName: json['checked_by_name'] as String?,
      mediaType: json['media_type'] as String? ?? 'photo',
      mediaUrl: json['media_url'] as String? ?? '',
      notes: json['notes'] as String?,
      checkedAt: json['checked_at'] != null
          ? DateTime.tryParse(json['checked_at'] as String)
          : null,
    );
  }

  bool get isPhoto => mediaType == 'photo';
  bool get isVideo => mediaType == 'video';
}
