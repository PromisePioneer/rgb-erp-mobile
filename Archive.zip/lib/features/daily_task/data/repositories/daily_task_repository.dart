import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import '../../../../core/core.dart';
import '../../domain/models/daily_task.dart';

DailyTaskRepository createDailyTaskRepository(Dio dio) {
  return DailyTaskRepository(api: DailyTaskApi(dio));
}

class DailyTaskRepository {
  final DailyTaskApi api;

  DailyTaskRepository({required this.api});

  Future<List<DailyTask>> getTodayTasks() async {
    try {
      final response = await api.getTodayTasks();
      final data = response['data'];
      if (data == null) return [];
      final list = data is List ? data : [];

      // Debug: log first item keys to see what fields are available
      if (list.isNotEmpty) {
        final firstItem = _toMap(list.first);
        debugPrint('=== getTodayTasks DEBUG ===');
        debugPrint('Keys: ${firstItem.keys.toList()}');
        debugPrint('notes: ${firstItem['notes']}');
        debugPrint('target_note: ${firstItem['target_note']}');
        debugPrint('===========================');
      }

      return list.map((json) => DailyTask.fromJson(_toMap(json))).toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat tugas harian: $e',
        statusCode: 500,
      );
    }
  }

  Future<DailyTask> getTaskDetail(int taskId) async {
    try {
      final response = await api.getTaskDetail(taskId);
      final data = response['data'];
      if (data == null) {
        throw ApiException(message: 'Tugas tidak ditemukan', statusCode: 404);
      }
      return DailyTask.fromJson(_toMap(data));
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat detail tugas: $e',
        statusCode: 500,
      );
    }
  }

  Future<List<DailyTaskMasterItem>> getItems({String? query, List<int>? roleIds}) async {
    try {
      final response = await api.getItems(query: query, roleIds: roleIds);
      final data = response['data'];

      // Debug logging
      debugPrint('getItems API response: success=${response['success']}, dataType=${data?.runtimeType}, dataLength=${data is List ? data.length : "not a list"}');

      if (data == null) return [];
      final list = data is List ? data : [];
      return list.map((json) => DailyTaskMasterItem.fromJson(_toMap(json))).toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      debugPrint('getItems error: $e');
      throw ApiException(
        message: 'Gagal memuat daftar item: $e',
        statusCode: 500,
      );
    }
  }

  Future<List<DailyTaskRole>> getRoles() async {
    try {
      final response = await api.getRoles();

      final data = response['data'];

      if (data == null) return [];
      final list = data is List ? data : [];

      final result = list.map((json) => DailyTaskRole.fromJson(_toMap(json))).toList();

      return result;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat daftar role: $e',
        statusCode: 500,
      );
    }
  }

  /// Search roles by query
  Future<List<DailyTaskRole>> searchRoles({String? query}) async {
    try {
      final response = await api.getRoles(query: query);

      final data = response['data'];

      if (data == null) return [];
      final list = data is List ? data : [];

      final result = list.map((json) => DailyTaskRole.fromJson(_toMap(json))).toList();

      return result;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat daftar role: $e',
        statusCode: 500,
      );
    }
  }

  /// Map integer category type to string for API
  String? _mapCategoryTypeToString(int? categoryType) {
    switch (categoryType) {
      case 1:
        return 'tools';
      case 2:
        return 'chemicals';
      case 3:
        return 'ppes';
      case 4:
        return 'machines';
      default:
        return null;
    }
  }

  Future<List<DailyTaskTool>> getTools({String? query, int? areaId, int? categoryType}) async {
    try {
      // If areaId is provided, fetch from product_areas (with stock data)
      if (areaId != null) {
        final response = await api.getDailyTaskProductsByArea(
          areaId: areaId,
          query: query,
          categoryType: _mapCategoryTypeToString(categoryType) ?? 'tools',
        );
        final data = response['data'];
        if (data == null) return [];
        final list = data is List ? data : [];
        return list.map((json) => DailyTaskTool.fromJson(_toMap(json))).toList();
      }
      // Otherwise, use original endpoint (from master products)
      final response = await api.getTools(query: query);
      final data = response['data'];
      if (data == null) return [];
      final list = data is List ? data : [];
      return list.map((json) => DailyTaskTool.fromJson(_toMap(json))).toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat daftar tools: $e',
        statusCode: 500,
      );
    }
  }

  Future<List<DailyTaskChemical>> getChemicals({String? query, int? areaId, int? categoryType}) async {
    try {
      // If areaId is provided, fetch from product_areas (with stock data)
      if (areaId != null) {
        final response = await api.getDailyTaskProductsByArea(
          areaId: areaId,
          query: query,
          categoryType: _mapCategoryTypeToString(categoryType) ?? 'chemicals',
        );
        final data = response['data'];
        if (data == null) return [];
        final list = data is List ? data : [];
        return list.map((json) => DailyTaskChemical.fromJson(_toMap(json))).toList();
      }
      // Otherwise, use original endpoint (from master products)
      final response = await api.getChemicals(query: query);
      final data = response['data'];
      if (data == null) return [];
      final list = data is List ? data : [];
      return list.map((json) => DailyTaskChemical.fromJson(_toMap(json))).toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat daftar chemicals: $e',
        statusCode: 500,
      );
    }
  }

  Future<List<DailyTaskPpe>> getPpes({String? query, int? areaId, int? categoryType}) async {
    try {
      // If areaId is provided, fetch from product_areas (with stock data)
      if (areaId != null) {
        final response = await api.getDailyTaskProductsByArea(
          areaId: areaId,
          query: query,
          categoryType: _mapCategoryTypeToString(categoryType) ?? 'ppes',
        );
        final data = response['data'];
        if (data == null) return [];
        final list = data is List ? data : [];
        return list.map((json) => DailyTaskPpe.fromJson(_toMap(json))).toList();
      }
      // Otherwise, use original endpoint (from master products)
      final response = await api.getPpes(query: query);
      final data = response['data'];
      if (data == null) return [];
      final list = data is List ? data : [];
      return list.map((json) => DailyTaskPpe.fromJson(_toMap(json))).toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat daftar PPE: $e',
        statusCode: 500,
      );
    }
  }

  Future<List<DailyTaskMachine>> getMachines({String? query, int? areaId, int? categoryType}) async {
    try {
      // If areaId is provided, fetch from product_areas (with stock data)
      if (areaId != null) {
        final response = await api.getDailyTaskProductsByArea(
          areaId: areaId,
          query: query,
          categoryType: _mapCategoryTypeToString(categoryType) ?? 'machines',
        );
        final data = response['data'];
        if (data == null) return [];
        final list = data is List ? data : [];
        return list.map((json) => DailyTaskMachine.fromJson(_toMap(json))).toList();
      }
      // Otherwise, use original endpoint (from master products)
      final response = await api.getMachines(query: query);
      final data = response['data'];
      if (data == null) return [];
      final list = data is List ? data : [];
      return list.map((json) => DailyTaskMachine.fromJson(_toMap(json))).toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat daftar mesin: $e',
        statusCode: 500,
      );
    }
  }

  Future<Map<String, dynamic>> getHistory({int page = 1, int perPage = 15}) async {
    try {
      final response = await api.getHistory(page: page, perPage: perPage);
      final data = response['data'];

      // Debug: log first item keys to see what fields are available
      if (data is List && data.isNotEmpty) {
        final firstItem = _toMap(data.first);
        debugPrint('=== getHistory DEBUG ===');
        debugPrint('Keys: ${firstItem.keys.toList()}');
        debugPrint('notes: ${firstItem['notes']}');
        debugPrint('target_note: ${firstItem['target_note']}');
        debugPrint('===========================');
      }

      return response;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat riwayat tugas: $e',
        statusCode: 500,
      );
    }
  }

  /// Start task - kondisi awal di-set otomatis oleh backend
  Future<DailyTask> startTask({
    required int taskId,
    required List<String> photos,
  }) async {
    try {
      final response = await api.startTask(
        taskId: taskId,
        photos: photos,
        // toolConditions, ppeConditions, machineConditions, chemicalConditions di-set otomatis oleh backend
      );
      final data = response['data'];
      if (data == null) {
        throw ApiException(message: 'Format response tidak valid', statusCode: 500);
      }
      return DailyTask.fromJson(_toMap(data));
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memulai tugas: $e',
        statusCode: 500,
      );
    }
  }

  Future<DailyTask> finishTask({
    required int taskId,
    required List<String> photos,
    String? notes,
    List<Map<String, String>>? toolConditions,
    List<Map<String, String>>? ppeConditions,
    List<Map<String, String>>? machineConditions,
    List<Map<String, String>>? chemicalConditions,
  }) async {
    try {
      final response = await api.finishTask(
        taskId: taskId,
        photos: photos,
        notes: notes,
        toolConditions: toolConditions,
        ppeConditions: ppeConditions,
        machineConditions: machineConditions,
        chemicalConditions: chemicalConditions,
      );
      final data = response['data'];
      if (data == null) {
        throw ApiException(message: 'Format response tidak valid', statusCode: 500);
      }
      return DailyTask.fromJson(_toMap(data));
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal menyelesaikan tugas: $e',
        statusCode: 500,
      );
    }
  }

  Map<String, dynamic> _toMap(dynamic value) {
    if (value == null) return {};
    if (value is Map<String, dynamic>) return value;
    if (value is Map) return Map<String, dynamic>.from(value);
    return {};
  }

  // ====================
  // Supervisor Assignment Methods
  // ====================

  Future<List<Map<String, dynamic>>> getAssignments({int page = 1, int perPage = 15, String? status}) async {
    try {
      final response = await api.getAssignments(page: page, perPage: perPage, status: status);
      final data = response['data'];
      if (data == null) return [];
      final list = (data is List ? data : []).map((json) => _toMap(json)).toList();

      // Debug: log first item keys to see what fields are available
      if (list.isNotEmpty) {
        final firstItem = list.first;
        debugPrint('=== getAssignments DEBUG ===');
        debugPrint('Keys: ${firstItem.keys.toList()}');
        debugPrint('notes: ${firstItem['notes']}');
        debugPrint('target_note: ${firstItem['target_note']}');
        debugPrint('===========================');
      }

      return list;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat daftar tugas: $e',
        statusCode: 500,
      );
    }
  }

  Future<List<Map<String, dynamic>>> getAssignmentEmployees() async {
    try {
      final response = await api.getAssignmentEmployees();
      final data = response['data'];
      if (data == null) return [];
      return (data is List ? data : []).map((json) => _toMap(json)).toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat daftar karyawan: $e',
        statusCode: 500,
      );
    }
  }

  Future<bool> createAssignment({
    required int employeeId,
    int? targetMinutes,
    String? assignedDate,
    String? notes,
  }) async {
    try {
      await api.createAssignment(
        employeeId: employeeId,
        targetMinutes: targetMinutes,
        assignedDate: assignedDate,
        notes: notes,
      );
      return true;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal membuat tugas: $e',
        statusCode: 500,
      );
    }
  }

  Future<bool> deleteAssignment(int id) async {
    try {
      await api.deleteAssignment(id);
      return true;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal menghapus tugas: $e',
        statusCode: 500,
      );
    }
  }

  /// DELETE /daily-task/{id} - Delete/cancel a task (for TL)
  Future<bool> deleteTask(int taskId) async {
    try {
      await api.deleteTask(taskId);
      return true;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal menghapus tugas: $e',
        statusCode: 500,
      );
    }
  }

  /// PUT /daily-task/{id} - Update a task (for TL)
  Future<Map<String, dynamic>?> updateTask({
    required int taskId,
    List<int>? employeeIds,
    int? itemId,
    String? assignedDate,
    int? targetMinutes,
    String? notes,
    List<int>? toolIds,
    List<int>? chemicalIds,
    List<int>? ppeIds,
  }) async {
    try {
      final response = await api.updateTask(
        taskId: taskId,
        employeeIds: employeeIds,
        itemId: itemId,
        assignedDate: assignedDate,
        targetMinutes: targetMinutes,
        notes: notes,
        toolIds: toolIds,
        chemicalIds: chemicalIds,
        ppeIds: ppeIds,
      );
      return response['data'] as Map<String, dynamic>?;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memperbarui tugas: $e',
        statusCode: 500,
      );
    }
  }

  // ====================
  // Mobile Task Assignment (uses daily_task_assign privilege)
  // ====================

  /// GET /daily-task/assign/employees - Get employees for mobile assignment
  /// Supports filtering by role_ids
  Future<List<Map<String, dynamic>>> getMobileAssignEmployees({String? query, List<int>? roleIds}) async {

    try {
      final response = await api.getMobileAssignEmployees(query: query, roleIds: roleIds);
      final data = response['data'];

      if (data == null) return [];
      return (data is List ? data : []).map((json) => _toMap(json)).toList();
    } on ApiException {
      rethrow;
    } catch (e) {

      throw ApiException(
        message: 'Gagal memuat daftar karyawan: $e',
        statusCode: 500,
      );
    }
  }

  /// POST /daily-task/assign - Assign task using mobile API (supports multiple employees)
  /// Returns the created assignment data
  Future<Map<String, dynamic>?> mobileAssignTask({
    required List<int> employeeIds,
    int? itemId,
    int? areaId,
    int? targetMinutes,
    String? targetNote,
    String? notes,
    String? assignedDate,
    List<int>? toolIds,
    List<int>? chemicalIds,
    List<int>? ppeIds,
    List<int>? machineIds,
  }) async {
    try {
      final response = await api.mobileAssignTask(
        employeeIds: employeeIds,
        itemId: itemId,
        areaId: areaId,
        targetMinutes: targetMinutes,
        targetNote: targetNote,
        notes: notes,
        assignedDate: assignedDate,
        toolIds: toolIds,
        chemicalIds: chemicalIds,
        ppeIds: ppeIds,
        machineIds: machineIds,
      );
      // Return the created assignment data from response
      // Normalize to match the shape expected by list screen (employee_name, employee_count, employee_names fields)
      final data = response['data'] as Map<String, dynamic>?;
      if (data != null && data.containsKey('assignees')) {
        final assignees = data['assignees'] as List?;
        if (assignees != null && assignees.isNotEmpty) {
          // Use first assignee's name as employee_name for list display
          final firstAssignee = assignees.first as Map<String, dynamic>;
          data['employee_name'] = firstAssignee['name'] ?? 'Unknown';
          // Include all assignee names as comma-separated string
          final names = assignees
              .map((a) => (a as Map<String, dynamic>)['name'] as String? ?? 'Unknown')
              .toList();
          data['employee_names'] = names.join(', ');
          data['employee_count'] = assignees.length;
        }
      }
      return data;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal membuat tugas: $e',
        statusCode: 500,
      );
    }
  }

  /// GET /daily-task/my-assignments - Get tasks assigned by current user (TL)
  Future<List<Map<String, dynamic>>> getMyAssignments() async {
    try {
      final response = await api.getMyAssignments();
      final data = response['data'];
      if (data == null) return [];
      return (data is List ? data : []).map((json) => _toMap(json)).toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat tugas: $e',
        statusCode: 500,
      );
    }
  }

  /// GET /daily-task/review-criteria - Get review criteria
  Future<List<Map<String, dynamic>>> getReviewCriteria() async {
    try {
      final response = await api.getReviewCriteria();
      final data = response['data'];
      if (data == null) return [];
      return (data is List ? data : []).map((json) => _toMap(json)).toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat kriteria review: $e',
        statusCode: 500,
      );
    }
  }

  /// POST /daily-task/{id}/review - Submit review
  Future<Map<String, dynamic>> submitReview({
    required int taskId,
    required List<Map<String, dynamic>> scores,
    String? notes,
  }) async {
    try {
      final response = await api.submitReview(
        taskId: taskId,
        scores: scores,
        notes: notes,
      );
      return response;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal menyimpan review: $e',
        statusCode: 500,
      );
    }
  }

  // ====================
  // Task Progress Check Methods (uses task_progress privilege)
  // ====================

  /// GET /daily-task/progress/tasks - Get tasks for progress checking
  Future<List<Map<String, dynamic>>> getProgressTasks() async {
    try {
      final response = await api.getProgressTasks();
      final data = response['data'];
      if (data == null) return [];
      final list = data is List ? data : [];
      return list.map((json) => _toMap(json)).toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat daftar tugas: $e',
        statusCode: 500,
      );
    }
  }

  /// POST /daily-task/{id}/progress-check - Submit progress check with photo
  Future<Map<String, dynamic>> submitProgressCheckPhoto({
    required int taskId,
    required int employeeId,
    required String photoBase64,
    String? notes,
  }) async {
    try {
      final response = await api.submitProgressCheckPhoto(
        taskId: taskId,
        employeeId: employeeId,
        photoBase64: photoBase64,
        notes: notes,
      );
      return response;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal menyimpan progress check: $e',
        statusCode: 500,
      );
    }
  }

  /// POST /daily-task/{id}/progress-check - Submit progress check with video
  Future<Map<String, dynamic>> submitProgressCheckVideo({
    required int taskId,
    required int employeeId,
    required String videoPath,
    String? notes,
  }) async {
    try {
      final response = await api.submitProgressCheckVideo(
        taskId: taskId,
        employeeId: employeeId,
        videoPath: videoPath,
        notes: notes,
      );
      return response;
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal menyimpan progress check: $e',
        statusCode: 500,
      );
    }
  }

  /// GET /daily-task/{id}/progress-checks - Get progress check history
  Future<List<Map<String, dynamic>>> getProgressChecks(int taskId) async {
    try {
      final response = await api.getProgressChecks(taskId);
      final data = response['data'];
      if (data == null) return [];
      final list = data is List ? data : [];
      return list.map((json) => _toMap(json)).toList();
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(
        message: 'Gagal memuat riwayat progress check: $e',
        statusCode: 500,
      );
    }
  }
}
